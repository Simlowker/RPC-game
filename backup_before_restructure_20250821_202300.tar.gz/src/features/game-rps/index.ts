// Main export for RPS Game feature
export { default as RPSGame } from './index.tsx';
export * from './types';
export * from './hooks/useRPSGame';
export * from './components/CreateMatchModal';
export * from './components/MatchLobby';
export * from './components/GameInterface';
export * from './components/MatchCard';
export * from './components/SoundSettings';
export * from './sounds/useSoundEffects';
export * from './animations/GameTransitions';
export * from './animations/ChoiceAnimations';